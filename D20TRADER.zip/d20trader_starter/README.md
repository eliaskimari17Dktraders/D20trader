# D20TRADER starter

A responsive starter project for D20TRADER. This is a UI + integration scaffold, not a live-money trading system.

## Included
- Responsive trading dashboard for phone and desktop
- Market watchlist and scanner panel (clearly marked preview data)
- Demo-first controls; trading is disabled by default
- Node/Express backend scaffold for OAuth callback and token exchange
- Environment-variable template

## Requirements
- Node.js 20+
- A Deriv OAuth application registered in the Deriv developer dashboard
- HTTPS redirect URL for deployment

## Run locally
```bash
npm install
cp .env.example .env
npm run dev
```
Open http://localhost:3000

## Deriv connection setup
1. Register a Deriv OAuth 2.0 application.
2. Set its redirect URI to `http://localhost:3000/auth/callback` for local testing (or your HTTPS production callback).
3. Put the registered client ID in `DERIV_CLIENT_ID`.
4. Set `APP_BASE_URL` to the same origin as the registered redirect URI.
5. Implement/deploy the server-side OAuth flow before enabling account features.

The OAuth flow must use Authorization Code + PKCE, validate `state`, and exchange the code on the backend. Never put access tokens, client secrets, or permanent API tokens in frontend JavaScript or public source control.

## Important status
- The current dashboard uses illustrative preview values.
- No live Deriv account is connected yet.
- No contract purchase code is enabled.
- Real trading must remain disabled until OAuth, account selection, demo testing, risk limits, and explicit user confirmation are complete.

## Official docs
- https://developers.deriv.com/docs/intro/oauth/
- https://developers.deriv.com/docs/intro/api-overview/
- https://developers.deriv.com/docs/trading/
