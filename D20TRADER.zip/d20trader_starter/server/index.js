require('dotenv').config();
const express = require('express');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const CLIENT_ID = process.env.DERIV_CLIENT_ID;
const BASE_URL = process.env.APP_BASE_URL || `http://localhost:${PORT}`;

app.use(express.static(path.join(__dirname, '..', 'public')));
app.use(express.json());

// OAuth PKCE scaffold. Production deployment should use a secure server-side
// session store and HTTPS. This in-memory map is for local development only.
const pendingAuth = new Map();

function base64url(buffer) {
  return buffer.toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}

app.get('/auth/deriv', (req, res) => {
  if (!CLIENT_ID || CLIENT_ID.includes('PUT_YOUR')) {
    return res.status(400).send('Set DERIV_CLIENT_ID in .env after registering your Deriv OAuth app.');
  }
  const verifier = base64url(crypto.randomBytes(32));
  const challenge = base64url(crypto.createHash('sha256').update(verifier).digest());
  const state = base64url(crypto.randomBytes(24));
  pendingAuth.set(state, { verifier, createdAt: Date.now() });

  const redirectUri = `${BASE_URL}/auth/callback`;
  const params = new URLSearchParams({
    response_type: 'code',
    client_id: CLIENT_ID,
    redirect_uri: redirectUri,
    scope: 'trade',
    state,
    code_challenge: challenge,
    code_challenge_method: 'S256'
  });
  res.redirect(`https://auth.deriv.com/oauth2/auth?${params.toString()}`);
});

app.get('/auth/callback', async (req, res) => {
  const { code, state, error } = req.query;
  if (error) return res.status(400).send(`Deriv authorization was not completed: ${String(error)}`);
  const saved = pendingAuth.get(state);
  if (!saved || Date.now() - saved.createdAt > 10 * 60 * 1000) {
    return res.status(400).send('OAuth state is missing, invalid, or expired. Please connect again.');
  }
  pendingAuth.delete(state);
  if (!code) return res.status(400).send('Missing authorization code.');

  // Token exchange intentionally left as a server-side integration step.
  // Implement POST https://auth.deriv.com/oauth2/token using:
  // grant_type=authorization_code, client_id, code, code_verifier,
  // redirect_uri. Store the resulting token in a secure server-side session.
  // Do not return tokens to the browser or log them.
  res.status(501).send(
    'OAuth callback received and state validated. Finish the server-side token exchange before using account data.'
  );
});

app.get('/api/status', (_req, res) => {
  res.json({
    app: 'D20TRADER',
    mode: 'preview',
    derivConnected: false,
    tradingEnabled: false
  });
});

app.listen(PORT, () => {
  console.log(`D20TRADER running at ${BASE_URL}`);
});
