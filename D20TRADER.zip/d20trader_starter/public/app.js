// D20TRADER frontend starter. Live feeds and account state are intentionally
// not simulated; connect the documented Deriv market-data and OAuth flows next.
fetch('/api/status').then(r => r.json()).then(status => {
  document.documentElement.dataset.derivConnected = String(status.derivConnected);
}).catch(() => {});
